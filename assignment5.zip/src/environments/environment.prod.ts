export const environment = {
  production: true,
  clientID: "94a46c1add6e4caf9d092f3fa7006718",
  clientSecret:"a7226708dc274c6cb33c2ef2b6ce2573"
};
